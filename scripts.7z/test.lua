local byte = string.char
local binfile = nil
local map = {}
local images = { }
local luminance =  {0x0,0xf,0x3,0xb,0x5,0x9,0x1,0xd,0x6,0x2,0xa,0x4,0x8,0xe,0x7,0xc,0xff}

--	we create a string for each char for comparison later
local function getTileData(img, x, y ,tw , th)
	local res = {}
	res.pixels = {}
	res.colors = {}
	res.string = ""

	table.insert(res.colors,0)

	for  cy = 0, th-1 do
		for cx = 0, tw-1 do
				--	get the pixel 
				px = img:getPixel(cx+x, cy+y)
				-- if we don't have this color for this tile then put it in the list 
				res.string = res.string .. string.format("%02x",px)
				px = px & 0xf
				local found = -1

				for i,v in ipairs(res.colors) do
					if px==v then 
						found = i 
						break
					end
				end

				if found==-1 then 
					table.insert(res.colors,px)
					found = #res.colors
				end
				table.insert(res.pixels,px)
		end
	end
	for i,v in ipairs(images) do
    if res.string==v.string then 
      return i -- Return the existent tile index that matches the "newTileImg"
    end
  end
  -- we add it and return the index of it.
	table.insert(images, res)
	return #images
end

local function CollectChars(input,tw,th)
	local sprite = input.sprite
	local img = Image(sprite.spec)
	img:drawSprite(sprite, input)

	for y = 0, img.height-1, tw do
		for x = 0, img.width-1, th do
			local data = getTileData(img, x, y , tw, th)
			table.insert(map,data)
		end
	end
end

local dlg = Dialog()
--[[
dlg:file{ id="exportFile",
          label="File",
          title="C64 Export",
          open=false,
          save=true,
          filetypes={"bin"}}
]]--
dlg:button{ id="ok", text="OK" }
dlg:show()

local data = dlg.data

if data.ok then
	--	ok was pressed
	CollectChars(app.activeFrame,8,8)

	binfile = io.open("e:/ase/tiles.bin", "wb")
	io.output(binfile)
	for key,tile in pairs(images) do 
		if #tile.colors<5 then

			table.sort(tile.colors, function(a, b) return luminance[1+(a&0xf)] < luminance[1+(b&0xf)] end)

			local indices = {0,1,2,3}
			--	lets remap the image to 4 colors here 
			for lines=0,7 do 
				c = 0
				for xp = 0, 7, 2 do 
					px = tile.pixels[1+((lines*8) + xp)]
					if px==nil then
						px = 0
					end

					local ox = 0 
					for ci = 1, #tile.colors do 
						if tile.colors[ci] == px then 
							ox = ci-1
							break
						end
					end
					c = c | ( ox << (6-xp))
				end
				io.write(byte(c))
			end
		else
			io.write(byte(0xff))
			io.write(byte(0x00))
			io.write(byte(0xaa))
			io.write(byte(0x55))
			io.write(byte(0x00))
			io.write(byte(0xaa))
			io.write(byte(0x55))
			io.write(byte(0xff))
		end
	end 
	io.close(binfile)

	binfile = io.open("e:/ase/tiles.map", "wb")
	io.output(binfile)
	for k,v in pairs(map) do 
		io.write(byte(v-1))
	end
	io.close(binfile)

end

